import { SubmittedDirective } from './submitted.directive';

describe('SubmittedDirective', () => {
  it('should create an instance', () => {
    const directive = new SubmittedDirective();
    expect(directive).toBeTruthy();
  });
});
