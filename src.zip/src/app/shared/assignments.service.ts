import { Injectable } from '@angular/core';
import {Assignment} from '../assignments/assignment.model';
import {Observable,of} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AssignmentsService {

		assignments: Assignment[]=[{
		name: 'one',
		duedate:new Date('2020-05-25'),
		submitted: true
	},

	{
		name: 'two',
		duedate: new Date('2020-05-25'),
		submitted: false

	}
	];


  constructor() {}

  getAssignments():Observable<Assignment[]>
  {
  	 return of(this.assignments);
  }

 }
