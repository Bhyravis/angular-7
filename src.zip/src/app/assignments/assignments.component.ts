import { Component, OnInit } from '@angular/core';
import { Assignment } from './assignment.model';
import {AssignmentsService} from '../shared/assignments.service';
import {interval} from 'rxjs';

@Component({
  selector: 'app-assignments',
  templateUrl: './assignments.component.html',
  styleUrls: ['./assignments.component.css']
})
export class AssignmentsComponent implements OnInit {

	title='my assignment';
	enable=false;
	selectedAssignment: Assignment;
  assignments:Assignment[];

  constructor(private assignmentService:AssignmentsService) { }

  ngOnInit(){
   // this.assignments=this.assignmentService.getAssignments();
  	this.getAssignments();
  }

  getAssignments(){
    this.assignmentService.getAssignments().subscribe(assignments=>this.assignments=assignments);

  }

  setSelected(assignment:Assignment){
      this.selectedAssignment=assignment;
    }

  onSubmit(name: string){
  	console.log(name);
  }

}
