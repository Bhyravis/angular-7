

export class Assignment{
	name: string;
	duedate:Date;
	submitted: boolean;
}